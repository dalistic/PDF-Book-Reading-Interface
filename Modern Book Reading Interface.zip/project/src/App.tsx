import React, { useState, useRef } from 'react';
import { Header } from './components/Header';
import { SettingsPanel } from './components/SettingsPanel';
import { Controls } from './components/Controls';
import { Pagination } from './components/Pagination';
import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

interface Page {
  content: string;
  originalContent: string;
  isTranslated: boolean;
}

function App() {
  const [pages, setPages] = useState<Page[]>([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [isReading, setIsReading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [fontSize, setFontSize] = useState('16px');
  const [lineHeight, setLineHeight] = useState('1.6');
  const [fontFamily, setFontFamily] = useState('Inter');
  const [speechRate, setSpeechRate] = useState(1);
  const [voiceLanguage, setVoiceLanguage] = useState('en-US');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textDisplayRef = useRef<HTMLDivElement>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type === 'application/pdf') {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      const pageTexts: Page[] = [];

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const text = textContent.items
          .map(item => ('str' in item ? item.str : ''))
          .join(' ')
          .replace(/\s+/g, ' ')
          .trim();

        pageTexts.push({
          content: text,
          originalContent: text,
          isTranslated: false
        });
      }

      setPages(pageTexts);
    } else {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        const pageSize = 1800;
        const pageArray: Page[] = [];
        
        for (let i = 0; i < text.length; i += pageSize) {
          const pageText = text.slice(i, i + pageSize);
          pageArray.push({
            content: pageText,
            originalContent: pageText,
            isTranslated: false
          });
        }
        
        setPages(pageArray);
      };
      reader.readAsText(file);
    }
    setCurrentPage(0);
  };

  const handleTranslate = async () => {
    if (!pages[currentPage]) return;
    
    const currentPageData = pages[currentPage];
    
    if (currentPageData.isTranslated) {
      // If already translated, revert to original content
      const updatedPages = [...pages];
      updatedPages[currentPage] = {
        ...currentPageData,
        content: currentPageData.originalContent,
        isTranslated: false
      };
      setPages(updatedPages);
    } else {
      try {
        const response = await fetch(
          `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=${encodeURIComponent(currentPageData.content)}`
        );
        const data = await response.json();
        const translatedText = data[0].map((item: any[]) => item[0]).join('');
        
        const updatedPages = [...pages];
        updatedPages[currentPage] = {
          ...currentPageData,
          content: translatedText,
          isTranslated: true
        };
        setPages(updatedPages);
      } catch (error) {
        console.error('Translation failed:', error);
      }
    }
  };

  const toggleReading = () => {
    if (isReading) {
      window.speechSynthesis.cancel();
      setIsReading(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(pages[currentPage]?.content);
      utterance.lang = voiceLanguage;
      utterance.rate = speechRate;
      window.speechSynthesis.speak(utterance);
      setIsReading(true);
      
      utterance.onend = () => setIsReading(false);
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  };

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage);
    if (textDisplayRef.current) {
      textDisplayRef.current.scrollTop = 0;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <div className="max-w-4xl mx-auto p-6">
        <Header
          onSettingsClick={() => setShowSettings(!showSettings)}
          onFullscreenClick={toggleFullscreen}
        />

        <div className="relative">
          {showSettings && (
            <SettingsPanel
              onClose={() => setShowSettings(false)}
              fontSize={fontSize}
              setFontSize={setFontSize}
              lineHeight={lineHeight}
              setLineHeight={setLineHeight}
              fontFamily={fontFamily}
              setFontFamily={setFontFamily}
              speechRate={speechRate}
              setSpeechRate={setSpeechRate}
              voiceLanguage={voiceLanguage}
              setVoiceLanguage={setVoiceLanguage}
            />
          )}

          <div className="bg-gray-800 rounded-lg p-6 shadow-xl">
            <Controls
              onFileClick={() => fileInputRef.current?.click()}
              onReadClick={toggleReading}
              onTranslateClick={handleTranslate}
              isReading={isReading}
              isTranslated={pages[currentPage]?.isTranslated}
            />
            
            <input
              ref={fileInputRef}
              type="file"
              accept=".txt,.pdf"
              onChange={handleFileUpload}
              className="hidden"
            />

            <div
              ref={textDisplayRef}
              className="min-h-[400px] max-h-[600px] overflow-y-auto bg-gray-900 rounded-lg p-6 mb-6 whitespace-pre-wrap"
              style={{ fontSize, lineHeight, fontFamily }}
            >
              {pages[currentPage]?.content || 'Upload a document to start reading...'}
            </div>

            <Pagination
              currentPage={currentPage}
              totalPages={pages.length}
              onFirstPage={() => handlePageChange(0)}
              onPrevPage={() => handlePageChange(Math.max(0, currentPage - 1))}
              onNextPage={() => handlePageChange(Math.min(pages.length - 1, currentPage + 1))}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;