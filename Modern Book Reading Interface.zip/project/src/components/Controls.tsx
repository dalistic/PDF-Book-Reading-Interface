import React from 'react';
import { Volume2, Languages } from 'lucide-react';

interface ControlsProps {
  onFileClick: () => void;
  onReadClick: () => void;
  onTranslateClick: () => void;
  isReading: boolean;
  isTranslated: boolean;
}

export function Controls({
  onFileClick,
  onReadClick,
  onTranslateClick,
  isReading,
  isTranslated,
}: ControlsProps) {
  return (
    <div className="flex gap-4 mb-6">
      <button
        onClick={onFileClick}
        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
      >
        Upload Document
      </button>
      
      <button
        onClick={onReadClick}
        className="flex items-center gap-2 bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg transition-colors"
      >
        <Volume2 className="w-5 h-5" />
        {isReading ? 'Stop Reading' : 'Read Aloud'}
      </button>
      
      <button
        onClick={onTranslateClick}
        className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-lg transition-colors"
      >
        <Languages className="w-5 h-5" />
        {isTranslated ? 'Show Original' : 'Translate'}
      </button>
    </div>
  );
}