import React from 'react';
import { X } from 'lucide-react';

interface SettingsPanelProps {
  onClose: () => void;
  fontSize: string;
  setFontSize: (size: string) => void;
  lineHeight: string;
  setLineHeight: (height: string) => void;
  fontFamily: string;
  setFontFamily: (font: string) => void;
  speechRate: number;
  setSpeechRate: (rate: number) => void;
  voiceLanguage: string;
  setVoiceLanguage: (lang: string) => void;
}

export function SettingsPanel({
  onClose,
  fontSize,
  setFontSize,
  lineHeight,
  setLineHeight,
  fontFamily,
  setFontFamily,
  speechRate,
  setSpeechRate,
  voiceLanguage,
  setVoiceLanguage,
}: SettingsPanelProps) {
  return (
    <div className="absolute right-0 top-0 w-80 bg-gray-800 p-6 rounded-lg shadow-xl z-10">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Settings</h2>
        <button onClick={onClose}>
          <X className="w-6 h-6" />
        </button>
      </div>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm mb-2">Font Size</label>
          <select
            value={fontSize}
            onChange={(e) => setFontSize(e.target.value)}
            className="w-full bg-gray-700 rounded-lg p-2"
          >
            <option value="14px">Small</option>
            <option value="16px">Medium</option>
            <option value="18px">Large</option>
            <option value="20px">Extra Large</option>
          </select>
        </div>

        <div>
          <label className="block text-sm mb-2">Line Height</label>
          <select
            value={lineHeight}
            onChange={(e) => setLineHeight(e.target.value)}
            className="w-full bg-gray-700 rounded-lg p-2"
          >
            <option value="1.4">Compact</option>
            <option value="1.6">Normal</option>
            <option value="1.8">Relaxed</option>
            <option value="2">Spacious</option>
          </select>
        </div>

        <div>
          <label className="block text-sm mb-2">Font Family</label>
          <select
            value={fontFamily}
            onChange={(e) => setFontFamily(e.target.value)}
            className="w-full bg-gray-700 rounded-lg p-2"
          >
            <option value="Inter">Inter</option>
            <option value="Georgia">Georgia</option>
            <option value="Times New Roman">Times New Roman</option>
            <option value="Arial">Arial</option>
          </select>
        </div>

        <div>
          <label className="block text-sm mb-2">Speech Rate</label>
          <select
            value={speechRate}
            onChange={(e) => setSpeechRate(Number(e.target.value))}
            className="w-full bg-gray-700 rounded-lg p-2"
          >
            <option value={0.8}>Slow</option>
            <option value={1}>Normal</option>
            <option value={1.2}>Fast</option>
          </select>
        </div>

        <div>
          <label className="block text-sm mb-2">Voice Language</label>
          <select
            value={voiceLanguage}
            onChange={(e) => setVoiceLanguage(e.target.value)}
            className="w-full bg-gray-700 rounded-lg p-2"
          >
            <option value="en-US">English</option>
            <option value="tr-TR">Turkish</option>
            <option value="es-ES">Spanish</option>
            <option value="fr-FR">French</option>
            <option value="de-DE">German</option>
          </select>
        </div>
      </div>
    </div>
  );
}