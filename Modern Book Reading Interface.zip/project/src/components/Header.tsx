import React from 'react';
import { Book, Settings, Maximize } from 'lucide-react';

interface HeaderProps {
  onSettingsClick: () => void;
  onFullscreenClick: () => void;
}

export function Header({ onSettingsClick, onFullscreenClick }: HeaderProps) {
  return (
    <header className="flex items-center justify-between mb-8">
      <h1 className="text-3xl font-bold flex items-center gap-2">
        <Book className="w-8 h-8" />
        Modern Reader
      </h1>
      <div className="flex gap-4">
        <button
          onClick={onSettingsClick}
          className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors"
        >
          <Settings className="w-6 h-6" />
        </button>
        <button
          onClick={onFullscreenClick}
          className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors"
        >
          <Maximize className="w-6 h-6" />
        </button>
      </div>
    </header>
  );
}